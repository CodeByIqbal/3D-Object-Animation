from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *

angle = 0

def draw_cube():
    global angle
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()
    glTranslatef(0, 0, -10)
    glRotatef(angle, 1, 1, 1)
    glutWireCube(2)
    glutSwapBuffers()
    angle += 1

def update(value):
    glutPostRedisplay()
    glutTimerFunc(10, update, 0)

def main():
    glutInit()
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH)
    glutInitWindowSize(500, 500)
    glutCreateWindow("3D Object Animation")
    glEnable(GL_DEPTH_TEST)
    glutDisplayFunc(draw_cube)
    glutTimerFunc(10, update, 0)
    glutMainLoop()

if _name_ == "_main_":
    main()